# Notepad starten
$process = Start-Process notepad.exe -PassThru

