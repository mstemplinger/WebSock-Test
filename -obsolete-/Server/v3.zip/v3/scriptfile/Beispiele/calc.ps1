# Notepad starten
$process = Start-Process calc.exe -PassThru

